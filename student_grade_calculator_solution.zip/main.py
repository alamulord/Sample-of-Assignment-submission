
import random
from datetime import datetime

students=[]

def display_menu():
    print("\n=== STUDENT GRADE CALCULATOR ===")
    print("1. Add Student")
    print("2. View Students")
    print("3. Save Records")
    print("4. Exit")

def calculate_average(m,e,s):
    return (m+e+s)/3

def calculate_grade(avg):
    if avg>=70: return "A"
    elif avg>=60: return "B"
    elif avg>=50: return "C"
    elif avg>=45: return "D"
    elif avg>=40: return "E"
    return "F"

def add_student():
    name=input("Name: ")
    math=int(input("Math: "))
    eng=int(input("English: "))
    sci=int(input("Science: "))
    avg=calculate_average(math,eng,sci)
    grade=calculate_grade(avg)
    student={
      "id":random.randint(1000,9999),
      "name":name,
      "math":math,
      "english":eng,
      "science":sci,
      "average":round(avg,2),
      "grade":grade,
      "date":datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    students.append(student)
    print("Student added!")

def view_students():
    if not students:
        print("No students found.")
        return
    for s in students:
        print("-"*30)
        for k,v in s.items():
            print(f"{k.title()}: {v}")

def save_students():
    with open("students.txt","w") as f:
        for s in students:
            f.write(f"{s['id']}|{s['name']}|{s['average']}|{s['grade']}|{s['date']}\n")
    print("Saved to students.txt")

def main():
    while True:
        display_menu()
        choice=input("Choose: ")
        if choice=="1":
            add_student()
        elif choice=="2":
            view_students()
        elif choice=="3":
            save_students()
        elif choice=="4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__=="__main__":
    main()
