# Student Grade Calculator
Run: python main.py
